package com.example.amma2_000.sms1;

import android.os.Bundle;
import android.app.Activity;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
    Button btn;
    EditText num;
    EditText txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = (Button) findViewById(R.id.button);
        num = (EditText) findViewById(R.id.phone_num);
        txt = (EditText) findViewById(R.id.msg);

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendSMSMessage();
            }
        });
    }

    protected void sendSMSMessage() {
        Log.i("Send a message", "");
        String phnum = num.getText().toString();
        String message = txt.getText().toString();

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phnum, null, message, null, null);
            Toast.makeText(getApplicationContext(), "message sent.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "message failed, please try again.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}